package com.example.DemoGraphQL.repository;

import com.example.DemoGraphQL.model.Pet;
import org.springframework.data.repository.CrudRepository;

public interface PetRepository extends CrudRepository<Pet, Long> {  }

